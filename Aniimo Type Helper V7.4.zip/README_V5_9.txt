V5.9: Consistent full-size None selectors; menus expand within their cards rather than overlapping other sections.
