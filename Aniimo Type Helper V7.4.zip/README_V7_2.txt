V7.2: Changed Ultimate / Sublime labels to Ultimate in the team editor and element picker. No layout or functionality changes.
