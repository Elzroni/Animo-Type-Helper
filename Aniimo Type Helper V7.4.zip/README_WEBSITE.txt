Aniimo Type Helper V3.4 FIXED
Open index.html in your browser, or run START_HERE_WINDOWS.bat.
Your existing teams remain in browser localStorage under aniimo_type_helper_v1.
Corrected 81-cell attack/defense table against Aniidex.
Cleaned proportional element selectors and results panel; Basic Attack included in all 4 move fields.
If your browser still shows old styling, press Ctrl+Shift+R.
