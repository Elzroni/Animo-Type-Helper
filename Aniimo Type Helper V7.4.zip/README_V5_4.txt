Aniimo Type Helper V5.4 — Mobile Fix Edition

Phone fixes: bottom-sheet element pickers, full-width result chips, tidy team member tabs, stacked Battle Arena teams, wrapped move icons, and mobile-friendly battle menus.

No changes to type calculations, localStorage keys, or saved team data.

To update Netlify: extract this ZIP and drag the extracted folder to your existing Netlify site Deploys page.
