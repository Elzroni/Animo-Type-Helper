V5.6 mobile Battle Arena fix: single-column selectable team cards and 40px fixed-size edit controls; cache-busted styles. Type calculations and localStorage data format unchanged.
