ANIIMO TYPE HELPER - VERSION 1 (WINDOWS)

1. Unzip the downloaded folder.
2. Double-click START_HERE_WINDOWS.bat.
3. Your browser should open the app. If it doesn't, visit http://localhost:8765
4. Keep the black Python server window open while using the app.
5. Close that window when you're done. Your inputs are saved automatically.

Requires Python 3. No pip installs, accounts, or internet access required.
All data is stored in this browser's local storage under http://localhost:8765.
Use the same browser every time. Clearing browser site data removes saved teams.
No JSON files to manage. Windows and phone syncing is NOT included in V1.

IMPORTANT: The type matrix was transcribed from your supplied Aniimo chart.
Dual-defender calculations multiply the two single-type values. This rule should
be verified against in-game dual-type examples. Damage multipliers show only
ELEMENTAL effectiveness, not actual damage or the strength of an Ultimate.

Features:
- Type Checker with radar-like effectiveness diagram
- 8 persistent team presets, each with 4 slots and 5 type inputs
- 4 vs 4 Battle Mode, including opponent move types
- Offensive and defensive effectiveness comparisons
- Battle history (save comparison button), reopen or delete
- Automatic local saving on every edit
- Responsive interface intended for future phone adaptation

V1 limitation: battle history is manually captured, not auto-recorded.

Version 1.1: Sky and reflective water theme; element icons on radar chart. Existing autosave storage key is unchanged.

Version 1.2: Duplicate defensive types automatically reset Type 2 to None. Existing saved data and history are normalized; damage calculation also deduplicates defensive types.

V2.5: Removed duplicate defensive type strips below team editors. Replaced fuzzy Ultimate glow with crisp colored outline and sparkle.
